if(!require('pacman')) install.packages('pacman')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(praise,
               tidyverse,
               dplyr)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  DONNÉES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.yaounde <- read_csv(here::here('data/fr_yaounde_data.csv'))
.yao <- .yaounde %>% 
  select(
    age, cat_age_3, sexe, poids_kg, taille_cm,
    quartier, fumeur, enceinte, occupation,
    combinaisons_traitement, symptomes, jours_absence_travail, jours_alite,
    edu_haute, resultat_igg)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 11)

.NUM_Q_resume_poids <- 1
.NUM_Q_resume_taille <- 2
.NUM_Q_poids_selon_statut_fumeur <- 3
.NUM_Q_min_max_taille_selon_sexe <- 4
.NUM_Q_somme_jours_alite <- 5
.NUM_Q_poids_selon_sexe_traitement <- 6
.NUM_Q_jours_alite_age_sex_igg <- 7
.NUM_Q_resume_occupation <- 8
.NUM_Q_compte_resultats <- 9
.NUM_Q_compte_jours_alite_age <- 10
.NUM_Q_mediane_quartier_age_sexe <- 11

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  RÉPONSES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_resume_poids ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_resume_poids <-
  function() {
    
    .problem_number <<- .NUM_Q_resume_poids
    reponse_correcte <- .yao %>%
      summarize(mean_poids_kg = mean(poids_kg),
                median_poids_kg = median(poids_kg),
                sd_poids_kg = sd(poids_kg))
    
    .autograder <<-
      function(){
        if(!exists("Q_resume_poids"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_resume_poids`.")
        if (!is.data.frame(Q_resume_poids))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"mean_poids_kg" %in% names(Q_resume_poids))
          .fail("Votre réponse doit avoir une colonne appelée 'mean_poids_kg'.")
        if (!"median_poids_kg" %in% names(Q_resume_poids))
          .fail("Votre réponse doit avoir une colonne appelée 'median_poids_kg'.")
        if (!"sd_poids_kg" %in% names(Q_resume_poids))
          .fail("Votre réponse doit avoir une colonne appelée 'sd_poids_kg'.")
        
        if (isTRUE(all.equal(Q_resume_poids, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_resume_poids <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_resume_poids <- 
  yao %>% 
  summarize(mean_poids_kg = FORMULE_ICI,
            median_poids_kg = FORMULE_ICI,
            sd_poids_kg = FORMULE_ICI)' -> out
  cat(out)
}

.SOLUTION_Q_resume_poids <- function(){
  '
SOLUTION
Q_resume_poids <- 
  yao %>%
      summarize(mean_poids_kg = mean(poids_kg),
                median_poids_kg = median(poids_kg),
                sd_poids_kg = sd(poids_kg))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_resume_taille ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_resume_taille <-
  function() {
    
    .problem_number <<- .NUM_Q_resume_taille
    reponse_correcte <- .yao %>%
      summarize(min_taille_cm = min(taille_cm),
                max_taille_cm = max(taille_cm))
    
    .autograder <<-
      function(){
        if(!exists("Q_resume_taille"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_resume_taille`.")
        if (!is.data.frame(Q_resume_taille))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"min_taille_cm" %in% names(Q_resume_taille))
          .fail("Votre réponse doit avoir une colonne appelée 'min_taille_cm'.")
        if (!"max_taille_cm" %in% names(Q_resume_taille))
          .fail("Votre réponse doit avoir une colonne appelée 'max_taille_cm'.")
        
        if (isTRUE(all.equal(Q_resume_taille, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_resume_taille <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_resume_taille <- 
  yao %>% 
  summarize(min_taille_cm = FORMULE_ICI,
            taille_max_cm = FORMULE_ICI)' -> out
  cat(out)
}

.SOLUTION_Q_resume_taille <- function(){
  '
SOLUTION
Q_resume_taille <- 
  yao %>%
      summarize(min_taille_cm = min(taille_cm),
                taille_max_cm = max(taille_cm))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_poids_selon_statut_fumeur ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_poids_selon_statut_fumeur <-
  function() {
    
    .problem_number <<- .NUM_Q_poids_selon_statut_fumeur
    reponse_correcte <- .yao %>%
      group_by(fumeur) %>%
      summarize(poids_moyen = mean(poids_kg, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_poids_selon_statut_fumeur"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_poids_selon_statut_fumeur`.")
        if (!is.data.frame(Q_poids_selon_statut_fumeur))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"poids_moyen" %in% names(Q_poids_selon_statut_fumeur))
          .fail("Votre réponse doit avoir une colonne appelée 'poids_moyen'.")
        
        if (isTRUE(all.equal(Q_poids_selon_statut_fumeur, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_poids_selon_statut_fumeur <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_poids_selon_statut_fumeur <- 
  yao %>% 
  group_by(fumeur) %>%
  summarize(poids_moyen = mean(poids_kg, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_poids_selon_statut_fumeur <- function(){
  '
SOLUTION
Q_poids_selon_statut_fumeur <- 
  yao %>% 
  group_by(fumeur) %>%
  summarize(poids_moyen = mean(poids_kg, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_min_max_taille_selon_sexe ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_min_max_taille_selon_sexe <-
  function() {
    
    .problem_number <<- .NUM_Q_min_max_taille_selon_sexe
    reponse_correcte <- .yao %>%
      group_by(sexe) %>%
      summarize(taille_min_cm = min(taille_cm, na.rm = TRUE),
                taille_max_cm = max(taille_cm, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_min_max_taille_selon_sexe"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_min_max_taille_selon_sexe`.")
        if (!is.data.frame(Q_min_max_taille_selon_sexe))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"taille_min_cm" %in% names(Q_min_max_taille_selon_sexe) || !"taille_max_cm" %in% names(Q_min_max_taille_selon_sexe))
          .fail("Votre réponse doit avoir des colonnes appelées 'taille_min_cm' et 'taille_max_cm'.")
        
        if (isTRUE(all.equal(Q_min_max_taille_selon_sexe, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_min_max_taille_selon_sexe <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_min_max_taille_selon_sexe <- 
  yao %>% 
  group_by(sexe) %>%
  summarize(taille_min_cm = min(taille_cm, na.rm = TRUE),
            taille_max_cm = max(taille_cm, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_min_max_taille_selon_sexe <- function(){
  '
SOLUTION
Q_min_max_taille_selon_sexe <- 
  yao %>% 
  group_by(sexe) %>%
  summarize(taille_min_cm = min(taille_cm, na.rm = TRUE),
            taille_max_cm = max(taille_cm, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_somme_jours_alite ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_somme_jours_alite <-
  function() {
    
    .problem_number <<- .NUM_Q_somme_jours_alite
    reponse_correcte <- .yao %>%
      group_by(sexe) %>%
      summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_somme_jours_alite"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_somme_jours_alite`.")
        if (!is.data.frame(Q_somme_jours_alite))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"total_jours_alite" %in% names(Q_somme_jours_alite))
          .fail("Votre réponse doit avoir une colonne appelée 'total_jours_alite'.")
        
        if (isTRUE(all.equal(Q_somme_jours_alite, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_somme_jours_alite <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_somme_jours_alite <- 
  yao %>% 
  group_by(sexe) %>%
  summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_somme_jours_alite <- function(){
  '
SOLUTION
Q_somme_jours_alite <- 
  yao %>% 
  group_by(sexe) %>%
  summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_poids_selon_sexe_traitement ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_poids_selon_sexe_traitement <-
  function() {
    
    .problem_number <<- .NUM_Q_poids_selon_sexe_traitement
    reponse_correcte <- .yao %>%
      group_by(sexe, combinaisons_traitement) %>%
      summarize(poids_moyen_kg = mean(poids_kg, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_poids_selon_sexe_traitement"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_poids_selon_sexe_traitement`.")
        if (!is.data.frame(Q_poids_selon_sexe_traitement))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"poids_moyen_kg" %in% names(Q_poids_selon_sexe_traitement))
          .fail("Votre réponse doit avoir une colonne appelée 'poids_moyen_kg'.")
        
        if (isTRUE(all.equal(Q_poids_selon_sexe_traitement, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_poids_selon_sexe_traitement <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_moyenne_poids_selon_sexe_traitement <- 
  yao %>% 
  group_by(sexe, combinaisons_traitement) %>%
  summarize(poids_moyen_kg = mean(poids_kg, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_poids_selon_sexe_traitement <- function(){
  '
SOLUTION
Q_poids_selon_sexe_traitement <- 
  yao %>% 
  group_by(sexe, combinaisons_traitement) %>%
  summarize(poids_moyen_kg = mean(poids_kg, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_jours_alite_age_sex_igg ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_jours_alite_age_sex_igg <-
  function() {
    
    .problem_number <<- .NUM_Q_jours_alite_age_sex_igg
    reponse_correcte <- .yao %>%
      group_by(age, sexe, resultat_igg) %>%
      summarize(moyenne_jours_alite = mean(jours_alite, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_jours_alite_age_sex_igg"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_jours_alite_age_sex_igg`.")
        if (!is.data.frame(Q_jours_alite_age_sex_igg))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"moyenne_jours_alite" %in% names(Q_jours_alite_age_sex_igg))
          .fail("Votre réponse doit avoir une colonne appelée 'moyenne_jours_alite'.")
        
        if (isTRUE(all.equal(Q_jours_alite_age_sex_igg, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_jours_alite_age_sex_igg <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_jours_alite_age_sex_igg <- 
  yao %>% 
  group_by(age, sexe, resultat_igg) %>%
  summarize(moyenne_jours_alite = mean(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_jours_alite_age_sex_igg <- function(){
  '
SOLUTION
Q_jours_alite_age_sex_igg <- 
  yao %>% 
  group_by(age, sexe, resultat_igg) %>%
  summarize(moyenne_jours_alite = mean(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_resume_occupation ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_resume_occupation <-
  function() {
    
    .problem_number <<- .NUM_Q_resume_occupation
    reponse_correcte <- .yao %>%
      group_by(occupation) %>%
      summarize(nombre = n(),
                moyenne_age = mean(age, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_resume_occupation"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_resume_occupation`.")
        if (!is.data.frame(Q_resume_occupation))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"nombre" %in% names(Q_resume_occupation) || !"moyenne_age" %in% names(Q_resume_occupation))
          .fail("Votre réponse doit inclure les colonnes 'nombre' et 'moyenne_age'.")
        
        if (isTRUE(all.equal(Q_resume_occupation, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_resume_occupation <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_resume_occupation <- 
  .yao %>% 
  group_by(occupation) %>%
  summarize(nombre = n(),
            moyenne_age = mean(age, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_resume_occupation <- function(){
  '
SOLUTION
Q_resume_occupation <- 
  .yao %>% 
  group_by(occupation) %>%
  summarize(nombre = n(),
            moyenne_age = mean(age, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_compte_resultats ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_compte_resultats <-
  function() {
    
    .problem_number <<- .NUM_Q_compte_resultats
    reponse_correcte <- .yao %>%
      group_by(sexe, age) %>%
      count(resultat_igg)
    
    .autograder <<-
      function(){
        if(!exists("Q_compte_resultats"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_compte_resultats`.")
        if (!is.data.frame(Q_compte_resultats))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"n" %in% names(Q_compte_resultats))
          .fail("Votre réponse doit avoir une colonne appelée 'n'.")
        
        if (isTRUE(all.equal(Q_compte_resultats, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_compte_resultats <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_compte_resultats <- 
  yao %>% 
  group_by(sexe, age) %>%
  count(resultat_igg)' -> out
  cat(out)
}

.SOLUTION_Q_compte_resultats <- function(){
  '
SOLUTION
Q_compte_resultats <- 
  yao %>% 
  group_by(sexe, age) %>%
  count(resultat_igg)' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_compte_jours_alite_age ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_compte_jours_alite_age <-
  function() {
    
    .problem_number <<- .NUM_Q_compte_jours_alite_age
    reponse_correcte <- .yao %>%
      group_by(cat_age_3) %>%
      summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_compte_jours_alite_age"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_compte_jours_alite_age`.")
        if (!is.data.frame(Q_compte_jours_alite_age))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"total_jours_alite" %in% names(Q_compte_jours_alite_age))
          .fail("Votre réponse doit avoir une colonne appelée 'total_jours_alite'.")
        
        if (isTRUE(all.equal(Q_compte_jours_alite_age, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_compte_jours_alite_age <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_compte_jours_alite_age <- 
  .yao %>% 
  group_by(cat_age_3) %>%
  summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_compte_jours_alite_age <- function(){
  '
SOLUTION
Q_compte_jours_alite_age <- 
  .yao %>% 
  group_by(cat_age_3) %>%
  summarize(total_jours_alite = sum(jours_alite, na.rm = TRUE))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_mediane_quartier_age_sexe ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_mediane_quartier_age_sexe <-
  function() {
    
    .problem_number <<- .NUM_Q_mediane_quartier_age_sexe
    reponse_correcte <- .yao %>%
      group_by(quartier, cat_age_3, sexe) %>%
      summarize(mediane_age = median(age, na.rm = TRUE))
    
    .autograder <<-
      function(){
        if(!exists("Q_mediane_quartier_age_sexe"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_mediane_quartier_age_sexe`.")
        if (!is.data.frame(Q_mediane_quartier_age_sexe))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"mediane_age" %in% names(Q_mediane_quartier_age_sexe))
          .fail("Votre réponse doit avoir une colonne appelée 'mediane_age'.")
        
        if (isTRUE(all.equal(Q_mediane_quartier_age_sexe, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_mediane_quartier_age_sexe <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_mediane_quartier_age_sexe <- 
  .yao %>% 
  group_by(quartier, cat_age_3, sexe) %>%
  summarize(mediane_age = median(age, na.rm = TRUE))' -> out
  cat(out)
}

.SOLUTION_Q_mediane_quartier_age_sexe <- function(){
  '
SOLUTION
Q_mediane_quartier_age_sexe <- 
  .yao %>% 
  group_by(quartier, cat_age_3, sexe) %>%
  summarize(mediane_age = median(age, na.rm = TRUE))' -> out
  cat(out)
}
