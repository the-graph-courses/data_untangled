if(!require('pacman')) install.packages('pacman')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(praise,
               tidyverse,
               dplyr)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  DONNÉES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

sarcopenia <- read_csv(here::here('data/fr_sarcopenia_elderly.csv'))

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 4)   # Mettez le nombre total de questions comme argument pour `times`

.NUM_Q_force_de_prehension_arrangee <- 1
.NUM_Q_groupe_d_age_taille <- 2
.NUM_Q_index_de_muscle_squelettique_max <- 3
.NUM_Q_classement_force_de_prehension <- 4

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  RÉPONSES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_force_de_prehension_arrangee ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_force_de_prehension_arrangee <-
  function() {
    
    .problem_number <<- .NUM_Q_force_de_prehension_arrangee
    reponse_correcte <- sarcopenia %>%
      select(sexe_homme_1_femme_0, force_de_prehension_kg) %>%
      arrange(sexe_homme_1_femme_0, force_de_prehension_kg)
    
    Q_force_de_prehension_arrangee <- .Last.value
    
    .autograder <<-
      function(){
        if(!exists("Q_force_de_prehension_arrangee"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_force_de_prehension_arrangee`.")
        if (!is.data.frame(Q_force_de_prehension_arrangee))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (isTRUE(all.equal(Q_force_de_prehension_arrangee, reponse_correcte, ignore_row_order = F)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_force_de_prehension_arrangee <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_force_de_prehension_arrangee <- 
  sarcopenia %>% 
  select(VARIABLES) %>%
  arrange(VARIABLES)' -> out
  cat(out)
}

.SOLUTION_Q_force_de_prehension_arrangee <- function(){
  '
SOLUTION
Q_force_de_prehension_arrangee <- 
  sarcopenia %>%
  select(sexe_homme_1_femme_0, force_de_prehension_kg) %>%
  arrange(sexe_homme_1_femme_0, force_de_prehension_kg)' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_groupe_d_age_taille ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_groupe_d_age_taille <-
  function() {
    
    .problem_number <<- .NUM_Q_groupe_d_age_taille
    reponse_correcte <- sarcopenia %>%
      mutate(groupe_d_age = factor(groupe_d_age, levels = c("Sixties",
                                                            "Seventies",
                                                            "Eighties"))) %>%
      arrange(groupe_d_age, taille_metres)
    
    .autograder <<-
      function(){
        if(!exists("Q_groupe_d_age_taille"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_groupe_d_age_taille`.")
        if (!is.data.frame(Q_groupe_d_age_taille))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (isTRUE(all.equal(Q_groupe_d_age_taille, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_groupe_d_age_taille <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_groupe_d_age_taille <- 
  sarcopenia %>% 
  mutate(groupe_d_age = TRANSFORMATION) %>%
  arrange(VARIABLES)' -> out
  cat(out)
}

.SOLUTION_Q_groupe_d_age_taille <- function(){
  '
SOLUTION
Q_groupe_d_age_taille <- 
  sarcopenia %>%
  mutate(groupe_d_age = factor(groupe_d_age, levels = c("Sixties",
                                                        "Seventies",
                                                        "Eighties"))) %>%
  arrange(groupe_d_age, taille_metres)' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_index_de_muscle_squelettique_max ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_index_de_muscle_squelettique_max <-
  function() {
    
    .problem_number <<- .NUM_Q_index_de_muscle_squelettique_max
    reponse_correcte <- sarcopenia %>%
      group_by(groupe_d_age, sexe_homme_1_femme_0) %>%
      filter(index_de_muscle_squelettique == max(index_de_muscle_squelettique))
    
    
    .autograder <<-
      function(){
        if(!exists("Q_index_de_muscle_squelettique_max"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_index_de_muscle_squelettique_max`.")
        if (!is.data.frame(Q_index_de_muscle_squelettique_max))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (isTRUE(all.equal(Q_index_de_muscle_squelettique_max, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_index_de_muscle_squelettique_max <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_index_de_muscle_squelettique_max <- 
  sarcopenia %>% 
  group_by(VARIABLES) %>%
  filter(FORMULE)' -> out
  cat(out)
}

.SOLUTION_Q_index_de_muscle_squelettique_max <- function(){
  '
SOLUTION
Q_index_de_muscle_squelettique_max <- 
  sarcopenia %>%
  group_by(groupe_d_age, sexe_homme_1_femme_0) %>%
  filter(index_de_muscle_squelettique == max(index_de_muscle_squelettique))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_classement_force_de_prehension ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_classement_force_de_prehension <-
  function() {
    
    .problem_number <<- .NUM_Q_classement_force_de_prehension
    reponse_correcte <- sarcopenia %>%
      group_by(groupe_d_age) %>%
      mutate(classement_force_de_prehension = rank(force_de_prehension_kg))
    
    
    .autograder <<-
      function(){
        if(!exists("Q_classement_force_de_prehension"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_classement_force_de_prehension`.")
        if (!is.data.frame(Q_classement_force_de_prehension))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (isTRUE(all.equal(Q_classement_force_de_prehension, reponse_correcte)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_classement_force_de_prehension <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_classement_force_de_prehension <- 
  sarcopenia %>% 
  group_by(VARIABLE) %>%
  mutate(classement_force_de_prehension = FORMULE)' -> out
  cat(out)
}

.SOLUTION_Q_classement_force_de_prehension <- function(){
  '
SOLUTION
Q_classement_force_de_prehension <- 
  sarcopenia %>%
  group_by(groupe_d_age) %>%
  mutate(classement_force_de_prehension = rank(force_de_prehension_kg))' -> out
  cat(out)
}
