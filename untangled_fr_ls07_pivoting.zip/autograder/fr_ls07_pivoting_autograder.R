if(!require('pacman')) install.packages('pacman')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(here, 
               glue,
               praise,
               janitor,
               tidyverse)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 5)   # Put total number of questions as `times` argument

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_type_donnees ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CHECK_Q_type_donnees <-
  function() {
    
    .problem_number <<- 1
    
    correct_answer <- "large"
    
    .autograder <<-
      function() {
        if (!exists("Q_type_donnees"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_type_donnees`.")
        
        if (!is.character(Q_type_donnees))
          .na("Réponse invalide. Votre réponse doit être un caractère")
        
        if (isTRUE(identical(tolower(trimws(Q_type_donnees)),
                             correct_answer)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_type_donnees <- function() {
  '
INDICE.
  Chaque unité observationnelle (chaque pays) occupe que une seule ligne.
' -> out
  cat(out)
}

.SOLUTION_Q_type_donnees <- function() {
  '
SOLUTION
  "large"' -> out
  cat(out)
}


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_euro_naissance_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_euro_naissance_long <-
  function() {
    
    .problem_number <<- 2
    
    .naissances_euro_large <- suppressMessages(read_csv(here("data/fr_euro_births_wide.csv")))
    
    .Q_euro_naissance_long <<- 
      .naissances_euro_large %>%
      pivot_longer(2:8, 
                   names_to = "annee", 
                   values_to = "nombre_de_naissances")
    
    
    .autograder <<-
      function() {
        if (!exists("Q_euro_naissance_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_euro_naissance_long`.")
        
        if (!is.data.frame(Q_euro_naissance_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_euro_naissance_long) != 3)
          .fail("Incorrect. Votre réponse doit avoir trois colonnes.")
        
        if (!all(names(Q_euro_naissance_long) %in% names(.Q_euro_naissance_long)) )
          .fail("Incorrect. Votre réponse doit avoir trois colonnes : pays, annee et nombre_de_naissances.")
        
        if (isTRUE(all.equal(.Q_euro_naissance_long,
                             Q_euro_naissance_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_euro_naissance_long <- function() {
  '
INDICE.
  Votre réponse devrait ressembler à cela :
  
  naissances_euro_large %>%
      pivot_longer(COLS A PIVOTER, 
                   names_to = NOM_COL, 
                   values_to = VALEUR_COL)' -> out
  cat(out)
}

.SOLUTION_Q_euro_naissance_long <- function() {
  '
SOLUTION
  naissances_euro_large %>%
      pivot_longer(2:8, 
                   names_to = "annee", 
                   values_to = "nombre_de_naissances")
' -> out
  cat(out)
}



##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_population_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CHECK_Q_population_large <-
  function() {
    
    .problem_number <<- 3
    
    
    .Q_population_large <- 
      tidyr::population %>% 
      pivot_wider(names_from = year,
                  values_from = population)
    
    
    .autograder <<-
      function() {
        if (!exists("Q_population_large"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_population_large`.")
        
        if (!is.data.frame(Q_population_large))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (!ncol(Q_population_large) == ncol(.Q_population_large))
          .fail(glue::glue("Incorrect. Votre réponse doit avoir {ncol(.Q_population_large)} colonnes."))
        
        if (! all(names(Q_population_large) %in% names(.Q_population_large)) )
          .fail(paste0("Incorrect. Votre réponse doit avoir ces colonnes :", 
                       paste0(names(.Q_population_large), collapse = ", ")
          ))
        
        if (isTRUE(suppressMessages(all.equal(Q_population_large,
                                              .Q_population_large, ignore_col_order = T, ignore_row_order = T))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_population_large <- function() {
  '
INDICE.
  Votre réponse devrait ressembler à cela :
  
  tidyr::population %>% 
      pivot_wider(names_from = COLONNES_FUTURE_NOMS,
                   values_from = COLONNES_PIVOTER)' -> out
  cat(out)
}

.SOLUTION_Q_population_large <- function() {
  '
SOLUTION
  
  tidyr::population %>% 
      pivot_wider(names_from = year,
                   values_from = population)' -> out
  cat(out)
}


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_population_max ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_population_max <-
  function() {
    
    .problem_number <<- 4
    
    
    .Q_population_max <- 
      tidyr::population %>% 
      group_by(country) %>% 
      filter(population == max(population)) %>% 
      ungroup()
    
    
    .autograder <<-
      function() {
        if (!exists("Q_population_max"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_population_max`.")
        
        if (!is.data.frame(Q_population_max))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (!nrow(Q_population_max) == nrow(.Q_population_max))
          .fail(glue::glue("Incorrect. Votre réponse doit avoir {nrow(.Q_population_max)} colonnes"))
        
        if (! all(names(Q_population_max) %in% names(.Q_population_max)) )
          .fail(paste0("Incorrect. Votre réponse doit avoir ces colonnes :", 
                       paste0(names(.Q_population_max), collapse = ", ")
          ))
        
        if (isTRUE(all.equal(Q_population_max,
                             .Q_population_max, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_population_max <- function() {
  '
INDICE.
  Votre réponse devrait ressembler à cela :
  
  tidyr::population %>% 
    group_by(country) %>% 
    FILTRE_POUR_MAX_POPULATION_PAR_GROUPE
    ungroup()' -> out
  cat(out)
}

.SOLUTION_Q_population_max <- function() {
  '
SOLUTION
  
  tidyr::population %>% 
    group_by(country) %>% 
    filter(population == max(population)) %>% 
    ungroup()' -> out
  cat(out)
}



##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_population_resumer ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_population_resumer <-
  function() {
    
    .problem_number <<- 5
    
    .Q_population_resumer <- 
      population %>% 
      group_by(country) %>% 
      summarise(max_population = max(population), 
                min_population = min(population), 
                moyen_population = mean(population))
    
    
    .autograder <<-
      function() {
        if (!exists("Q_population_resumer"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_population_resumer`.")
        
        if (!is.data.frame(Q_population_resumer))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (!nrow(Q_population_resumer) == nrow(.Q_population_resumer))
          .fail(glue::glue("Incorrect. Votre réponse doit avoir {nrow(.Q_population_resumer)} colonnes."))
        
        if (! all(names(Q_population_resumer) %in% names(.Q_population_resumer)) )
          .fail(paste0("Incorrect. Votre réponse doit avoir ces colonnes :", 
                       paste0(names(.Q_population_resumer), collapse = ", ")
          ))
        
        if (isTRUE(all.equal(Q_population_resumer,
                             .Q_population_resumer, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_population_resumer <- function() {
  '
INDICE.
  Votre réponse devrait ressembler à cela :
  
  population %>% 
  group_by(country) %>% 
  summarise(max_population = , 
            min_population = , 
            mean_population = )' -> out
  cat(out)
}

.SOLUTION_Q_population_resumer <- function() {
  '
SOLUTION
  
  population %>% 
  group_by(country) %>% 
  summarise(max_population = max(population), 
            min_population = min(population), 
            mean_population = mean(population))' -> out
  cat(out)
}

