if(!require('pacman')) install.packages('pacman')

pacman::p_install_gh('graph-courses/autograder')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(here, 
               glue,
               praise,
               janitor,
               tidyverse)


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  DONNÉES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.liste_influ <- read_csv(here::here('data/fr_flu_h7n9_china_2013.csv'))

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 9)   # Mettez le nombre total de questions comme argument pour `times`

.NUM_Q_age_groupe <- 1
.NUM_Q_age_groupe_pourcentage <- 2
.NUM_Q_age_groupe_nas <- 3
.NUM_Q_sexe_recoder <- 4
.NUM_Q_recoder_recovery <- 5
.NUM_Q_adolescent_grouping <- 6
.NUM_Q_age_province_grouping <- 7
.NUM_Q_priorite_groupes <- 8
.NUM_Q_age_groupe_if_else <- 9


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  RÉPONSES ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_age_groupe ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_age_groupe <-
  function() {
    
    .problem_number <<- .NUM_Q_age_groupe
    
    correct_answer <- .liste_influ %>% 
      mutate(age_groupe = case_when(age < 50 ~ "Moins de 50", 
                                    age >= 50 ~ "50 et plus"))
    
    .autograder <<-
      function(){
        if(!exists("Q_age_groupe"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_age_groupe`.")
        if (!is.data.frame(Q_age_groupe))
          .na("Réponse invalide. Votre réponse doit être un data frame.")
        if (!"age_groupe" %in% names(Q_age_groupe))
          .fail("Votre réponse doit avoir une colonne appelée 'age_groupe'.")
        
        if (isTRUE(all.equal(select(Q_age_groupe, age_groupe) , 
                             select(correct_answer, age_groupe))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }


.HINT_Q_age_groupe <- function(){
  '
INDICE.
Votre réponse devrait ressembler à cela : 

Q_age_groupe <- 
  liste_influ %>% 
  mutate(age_groupe = FORMULE_ICI)' -> out
  cat(out)
}

.SOLUTION_Q_age_groupe <- function(){
  '
SOLUTION
Q_age_groupe <- 
  liste_influ %>% 
  mutate(age_groupe = case_when(age < 50 ~ "Moins de 50", 
                                age >= 50 ~ "50 et plus"))' -> out
  cat(out)
}

# # Check autograder
# Q_age_groupe <-
#   liste_influ %>%
#   mutate(age_groupe = case_when(age < 50 ~ "Moins de 50",
#                                 age >= 50 ~ "50 et plus"))
# .CHECK_Q_age_groupe()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_age_groupe_pourcentage ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_age_groupe_pourcentage <-
  function() {
    
    .problem_number <<- .NUM_Q_age_groupe_pourcentage
    
    correct_answer <- 
      .liste_influ %>% 
      mutate(age_groupe_pourcentage = case_when(age < 60 ~ "Moins de 60", 
                                              age >= 60 ~ "60 et plus")) %>% 
      tabyl(age_groupe_pourcentage) %>% 
      filter(age_groupe_pourcentage == "Moins de 60") %>% 
      pull(percent) * 100
    
    
    .autograder <<-
      function(){
        if(!exists("Q_age_groupe_pourcentage"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_age_groupe_pourcentage`.")
        if (!is.numeric(Q_age_groupe_pourcentage))
          .na("Réponse invalide. Votre réponse doit être un numéro.")
        if (between(Q_age_groupe_pourcentage, correct_answer/100 - 0.1, correct_answer/100 + 0.1))
          .fail("Il se peut que vous saisissiez une fraction décimale, plutôt qu'un pourcentage")
        if (between(Q_age_groupe_pourcentage, correct_answer - 1, correct_answer + 1))
          .pass("Correct!")
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_age_groupe_pourcentage <- function(){
  '
HINT
   Idéalement, écrivez un appel à case_when() qui contient les conditions `age < 60`, puis appelez janitor::tabyl() sur votre variable créée.
' -> out
  cat(out)
}


.SOLUTION_Q_age_groupe_pourcentage <- function(){
  '
SOLUTION. Voici une manière (pas la seule) de l’obtenir :
  
Q_age_groupe_pourcentage <- 
  liste_influ %>% 
      mutate(age_group_percentage = case_when(age < 60 ~ "Moins de 60", 
                                              age >= 60 ~ "60 et plus")) %>% 
      tabyl(age_group_percentage) %>% 
      filter(age_group_percentage == "Moins de 60") %>% 
      pull(percent) * 100' -> out
  cat(out)
}

# ## Check autograder
# Q_age_groupe_pourcentage <-
#   liste_influ %>%
#   mutate(age_groupe_pourcentage = case_when(age < 60 ~ "Moins de 60",
#                                             age >= 60 ~ "60 et plus")) %>%
#   tabyl(age_groupe_pourcentage) %>%
#   filter(age_groupe_pourcentage == "Moins de 60") %>%
#   pull(percent) * 100
# 
# 
# .CHECK_Q_age_groupe_pourcentage()
# .HINT_Q_age_groupe_pourcentage()
# .SOLUTION_Q_age_groupe_pourcentage()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_age_groupe_nas ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_age_groupe_nas <-
  function() {
    
    .problem_number <<- .NUM_Q_age_groupe_nas
    correct_answer <- .liste_influ %>%  
      mutate(age_groupe = case_when(age < 60 ~ "Moins de 60", 
                                   age >= 60 ~ "60 et plus", 
                                   is.na(age) ~ "Age manquant"))
    
    .autograder <<-
      function(){
        if(!exists("Q_age_groupe_nas"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_age_groupe_nas`.")
        if (!is.data.frame(Q_age_groupe_nas))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"age_groupe" %in% names(Q_age_groupe_nas))
          .fail("Votre réponse devrait avoir une colonne appelée 'age_groupe'.")
        
        
        if (isTRUE(all.equal(select(Q_age_groupe_nas, age_groupe), 
                             select(correct_answer, age_groupe))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_age_groupe_nas <- function(){
  '
HINT.
Votre réponse devrait ressembler à ceci : 

Q_age_groupe_nas <- 
  liste_influ %>% 
  mutate(age_groupe = FORMULE_ICI)' -> out
  cat(out)
}

.SOLUTION_Q_age_groupe_nas <- function(){
  '
SOLUTION
Q_age_groupe_nas <- 
  liste_influ %>% 
  mutate(age_groupe = case_when(age < 60 ~ "Moins de 60", 
                               age >= 60 ~ "60 et plus", 
                               is.na(age) ~ "Age manquant"))' -> out
  cat(out)
}

# ## Check autograder
# Q_age_groupe_nas <-
#   liste_influ %>%
#   mutate(age_groupe = case_when(age < 60 ~ "Moins de 60",
#                                age >= 60 ~ "60 et plus",
#                                is.na(age) ~ "Age manquant"))
# .CHECK_Q_age_groupe_nas()
# .HINT_Q_age_groupe_nas()
# .SOLUTION_Q_age_groupe_nas()
# 

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_sexe_recoder ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_sexe_recoder <-
  function() {
    
    .problem_number <<- .NUM_Q_sexe_recoder
    correct_answer <- .liste_influ %>%  
      mutate(sexe = case_when(sexe == "f" ~ "Femme",
                              sexe == "m" ~ "Homme", 
                              is.na(sexe) ~ "Sexe manquant"))
    
    .autograder <<-
      function(){
        if(!exists("Q_sexe_recoder"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_sexe_recoder`.")
        if (!is.data.frame(Q_sexe_recoder))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"sexe" %in% names(Q_sexe_recoder))
          .fail("Votre réponse devrait avoir une colonne appelée 'sexe'.")
        
        
        if (isTRUE(all.equal(select(Q_sexe_recoder, sexe), 
                             select(correct_answer, sexe))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_sexe_recoder <- function(){
  '
INDICE.
Votre réponse devrait ressembler à ceci : 

Q_sexe_recoder <- 
  liste_influ %>% 
  mutate(sexe = case_when(FORMULE_ICI))' -> out
  cat(out)
}

.SOLUTION_Q_sexe_recoder <- function(){
  '
SOLUTION
Q_sexe_recoder <- 
  liste_influ %>%  
      mutate(sexe = case_when(sexe == "f" ~ "Femme",
                              sexe == "m" ~ "Homme",
                              is.na(sexe) ~ "Sexe manquant"))' -> out
  cat(out)
}

# # Check autograder
# Q_sexe_recoder <- 
#   liste_influ %>%  
#   mutate(sexe = case_when(sexe == "f" ~ "Femme",
#                           sexe == "m" ~ "Homme",
#                           is.na(sexe) ~ "Sexe manquant"))
# 
# .CHECK_Q_sexe_recoder()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_recoder_recover
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_recoder_recovery <-
  function() {
    
    .problem_number <<- .NUM_Q_recoder_recovery
    correct_answer <- .liste_influ %>%  
      mutate(devenir = case_when(devenir == "Recover" ~ "Recovery", 
                                  TRUE ~ devenir))
    
    .autograder <<-
      function(){
        if(!exists("Q_recoder_recovery"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_recoder_recovery`.")
        if (!is.data.frame(Q_recoder_recovery))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"devenir" %in% names(Q_recoder_recovery))
          .fail("Votre réponse devrait avoir une colonne appelée 'devenir'.")
        
        
        if (isTRUE(all.equal(select(Q_recoder_recovery, devenir), 
                             select(correct_answer, devenir))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_recoder_recovery <- function(){
  '
INDICE.
Votre réponse devrait ressembler à ceci : 

Q_recoder_recovery <- 
  liste_influ %>% 
  mutate(devenir = FORMULE_ICI)' -> out
  cat(out)
}

.SOLUTION_Q_recoder_recovery <- function(){
  '
SOLUTION
Q_recoder_recovery <- 
  liste_influ %>% 
  mutate(devenir = case_when(devenir == "Recover" ~ "Recovery", 
                                 TRUE ~ devenir))' -> out
  cat(out)
}

# # Check autograders
# Q_recoder_recovery <-
#   liste_influ %>%
#   mutate(devenir = case_when(devenir == "Recover" ~ "Recovery",
#                               TRUE ~ devenir))
# 
# .CHECK_Q_recoder_recovery()
# .HINT_Q_recoder_recovery()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_adolescent_grouping ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_adolescent_grouping <-
  function() {
    
    .problem_number <<- .NUM_Q_adolescent_grouping
    correct_answer <- .liste_influ %>% 
      mutate(adolescent = case_when(
        age >= 10 & age < 20 ~ "Oui",
        TRUE ~ "Non"
      ))
    
    erreur1 <- .liste_influ %>% 
      mutate(adolescent = case_when(
        age >= 10 & age < 19 ~ "Oui",
        TRUE ~ "Non"
      ))
    
    .autograder <<-
      function(){
        if(!exists("Q_adolescent_grouping"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_adolescent_grouping`.")
        if (!is.data.frame(Q_adolescent_grouping))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"adolescent" %in% names(Q_adolescent_grouping))
          .fail("Votre réponse devrait avoir une colonne appelée 'adolescent'.")
        
        if (isTRUE(all.equal(select(Q_adolescent_grouping, adolescent), 
                             select(erreur1, adolescent))))
          .fail("Votre condition devrait être `age >= 10 & age < 20`")
        
        if (isTRUE(all.equal(select(Q_adolescent_grouping, adolescent), 
                             select(correct_answer, adolescent))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_adolescent_grouping <- function(){
  '
INDICE.
La condition de gauche (LHS) devrait prendre la forme `age >= 10 & age < 20`' -> out
  cat(out)
}


.SOLUTION_Q_adolescent_grouping <- function(){
  '
SOLUTION
Q_adolescent_grouping <- 
  liste_influ %>% 
      mutate(adolescent = case_when(
        age >= 10 & age < 20 ~ "Yes",
        TRUE ~ "No"))' -> out
  cat(out)
}

# Check autograder
# Q_adolescent_grouping <- 
#   liste_influ %>% 
#   mutate(adolescent = case_when(
#     age >= 10 & age < 20 ~ "Oui",
#     TRUE ~ "Non"
#   ))
# 
# .CHECK_Q_adolescent_grouping()
# .HINT_Q_adolescent_grouping()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_age_province_grouping ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_age_province_grouping <-
  function() {
    
    .problem_number <<- .NUM_Q_age_province_grouping
    correct_answer <- .liste_influ %>% 
      mutate(recruter = case_when(
        province == "Jiangsu" & (age >= 30 & age < 60) ~ "Recruter pour l'étude Jiangsu",
        province == "Zhejiang" & (age >= 30 & age < 60) ~ "Recruter pour l'étude Zhejiang",
        TRUE ~ "Ne pas recruter"
      ))
    
    .autograder <<-
      function(){
        if(!exists("Q_age_province_grouping"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_age_province_grouping`.")
        if (!is.data.frame(Q_age_province_grouping))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"recruter" %in% names(Q_age_province_grouping))
          .fail("Votre réponse devrait avoir une colonne appelée 'recruter'.")
        
        
        if (isTRUE(all.equal(select(Q_age_province_grouping, recruter), 
                             select(correct_answer, recruter))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_age_province_grouping <- function(){
  '
INDICE.
Voici un exemple de condition pour la partie gauche (LHS) : 
  `age >= 30 & age <= 59 & province == "Zhejiang" ~ "Recruter pour l’étude Zhejiang"` ' -> out
  cat(out)
}

.SOLUTION_Q_age_province_grouping <- function(){
  '
SOLUTION
Q_age_province_grouping <- 
  liste_influ %>% 
      mutate(recruter = case_when(
        province == "Jiangsu" & (age >= 30 & age < 60) ~ "Recruter pour l’étude Jiangsu",
        province == "Zhejiang" & (age >= 30 & age < 60) ~ "Recruter pour l’étude Zhejiang",
        TRUE ~ "Ne pas recruter"))' -> out
  cat(out)
}

# # Check autograder
# Q_age_province_grouping <- 
#   liste_influ %>% 
#   mutate(recruter = case_when(
#     province == "Jiangsu" & (age >= 30 & age < 60) ~ "Recruter pour l'étude Jiangsu",
#     province == "Zhejiang" & (age >= 30 & age < 60) ~ "Recruter pour l'étude Zhejiang",
#     TRUE ~ "Ne pas recruter"
#   ))

# .CHECK_Q_age_province_grouping()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_priorite_groupes ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.CHECK_Q_priorite_groupes <-
  function() {
    
    .problem_number <<- .NUM_Q_priorite_groupes
    correct_answer <- .liste_influ %>% 
      mutate(priorite_de_suivi = case_when(
        age < 18 ~ "Haute priorité", 
        sexe == "f" ~ "Priorité la plus élevée", 
        TRUE ~ "Pas de priorité"
      ))
    
    erreur1 <- .liste_influ %>% 
      mutate(priorite_de_suivi = case_when(sexe == "f" ~ "Haute priorité",
                                            age < 18 ~ "Priorité la plus élevée", 
                                            TRUE ~ "Pas de priorité"
      ))
    
    
    .autograder <<-
      function(){
        if(!exists("Q_priorite_groupes"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_priorite_groupes`.")
        if (!is.data.frame(Q_priorite_groupes))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"priorite_de_suivi" %in% names(Q_priorite_groupes))
          .fail("Votre réponse devrait avoir une colonne appelée 'priorite_de_suivi'.")
        
        
        if (isTRUE(all.equal(select(Q_priorite_groupes, priorite_de_suivi) , 
                             select(erreur1, priorite_de_suivi))))
          .fail(paste0("Incorrect. Il semble que vous ayez placé la condition de sexe en premier. Cela signifie qu'elle est prioritaire par rapport à la condition d'âge", 
                       "C’est-à-dire qu’avec ce que vous avez codé, les enfants de sexe féminin n’auront pas la priorité absolue, mais seulement les enfants de sexe masculin !",
                       "Mais la question dit que les enfants, quel que soit leur sexe, doivent être prioritaires",
                       "Cette condition doit donc être placée en premier dans votre déclaration case_when()."))
        
        
        if (isTRUE(all.equal(select(Q_priorite_groupes, priorite_de_suivi) , 
                             select(correct_answer, priorite_de_suivi))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_priorite_groupes <- function(){
  '
HINT.

La condition liée à l’âge doit venir en premier, afin d’être prioritaire par rapport aux autres.' -> out
  cat(out)
}

.SOLUTION_Q_priorite_groupes <- function(){
  '
SOLUTION
Q_priorite_groupes <- 
  liste_influ %>% 
      mutate(priorite_de_suivi = case_when(
        age < 18 ~ "Haute priorité", 
        sexe == "f" ~ "Priorité la plus élevée", 
        TRUE ~ "Pas de priorité"
      ))' -> out
  cat(out)
}


# Check autograder
# Q_priorite_groupes <- 
#   liste_influ %>% 
#   mutate(priorite_de_suivi = case_when(
#     age < 18 ~ "Haute priorité", 
#     sexe == "f" ~ "Priorité la plus élevée", 
#     TRUE ~ "Pas de priorité"
#   ))

# .CHECK_Q_priorite_groupes()
# .HINT_Q_priorite_groupes()

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_age_groupe_if_else ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_age_groupe_if_else <-
  function() {
    
    .problem_number <<- .NUM_Q_age_groupe_if_else
    correct_answer <- .liste_influ %>% 
      mutate(age_groupe = if_else(age < 50, "Moins de 50", "50 et plus"))
    
    .autograder <<-
      function(){
        if(!exists("Q_age_groupe_if_else"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_age_groupe_if_else`.")
        if (!is.data.frame(Q_age_groupe_if_else))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        if (!"age_groupe" %in% names(Q_age_groupe_if_else))
          .fail("Votre réponse devrait avoir une colonne appelée 'age_groupe'.")
        
        
        if (isTRUE(all.equal(select(Q_age_groupe_if_else, age_groupe) , 
                             select(correct_answer, age_groupe))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_age_groupe_if_else <- function(){
  '
HINT.
Votre réponse devrait être comme celci : 

Q_age_groupe_if_else <- 
  liste_influ %>% 
  mutate(age_groupe = if_else(age = FORMULE_ICI))' -> out
  cat(out)
}

.SOLUTION_Q_age_groupe_if_else <- function(){
  '
SOLUTION
Q_age_groupe_if_else <- 
  liste_influ %>% 
  mutate(age_groupe = if_else(age < 50, "Moins de 50", "50 et plus"))' -> out
  cat(out)
}

# Check autograder

# Q_age_groupe_if_else <- 
#   liste_influ %>% 
#   mutate(age_groupe = if_else(age < 50, "Moins de 50", "50 et plus"))
# 
# .CHECK_Q_age_groupe_if_else()
# .HINT_Q_age_groupe_if_else()
