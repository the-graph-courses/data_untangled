if(!require('pacman')) install.packages('pacman')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(here, 
               glue,
               praise,
               janitor,
               tidyverse)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 6)   # Put total number of questions as `times` argument

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_adulte_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CHECK_Q_adulte_long <-
  function() {
    
    .problem_number <<- 1
    
    .adulte_stats <- 
      tibble::tribble(
        ~adulte,  ~annee1_IMC,  ~annee2_IMC,  ~annee1_VIH,  ~annee2_VIH,
        "A",          25,          30,  "Positive",  "Positive",
        "B",          34,          28,  "Negative",  "Positive",
        "C",          19,          17,  "Negative",  "Negative"
      )
    
    .Q_adulte_long <- 
      .adulte_stats %>%
      pivot_longer(cols = 2:5,
                   names_sep = "_",
                   names_to = c("annee", ".value"))
    
    .autograder <<-
      function() {
        if (!exists("Q_adulte_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_adulte_long`.")
        
        if (!is.data.frame(Q_adulte_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_adulte_long) != 4)
          .fail("Incorrect. Votre réponse doit avoir quatre colonnes.")
        
        if (!all(names(Q_adulte_long) %in% names(.Q_adulte_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : adulte, annee, IMC, VIH")
        
        if (isTRUE(all.equal(.Q_adulte_long,
                             Q_adulte_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_adulte_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:5` pour sélectionner les colonnes à pivoter. 
  - Utilisez `names_sep = "_"` et `names_to = c("year", ".value")` pour formater les noms.
  ' -> out
  cat(out)
}


.SOLUTION_Q_adulte_long <- function() {
  '
SOLUTION
  
  adulte_stats %>%
      pivot_longer(cols = 2:5,
                   names_sep = "_",
                   names_to = c("annee", ".value"))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_croissance_stats_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_croissance_stats_long <-
  function() {
    
    .problem_number <<- 2
    
    .croissance_stats <- 
      tibble::tribble(
        ~enfant,~ann1_tete,~ann2_tete,~ann1_cou,~ann2_cou,~ann1_hanche,~ann2_hanche,
        "a",         45,        48,       23,       24,          51,          52,
        "b",         48,        50,       24,       26,          52,          52,
        "c",         50,        52,       24,       27,          53,          54
      )
    
    .Q_croissance_stats_long <- 
      .croissance_stats %>%
      pivot_longer(cols = 2:7,
                   names_to = c("annee", ".value"),
                   names_sep = "_")
    
    .autograder <<-
      function() {
        if (!exists("Q_croissance_stats_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_croissance_stats_long`.")
        
        if (!is.data.frame(Q_croissance_stats_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_croissance_stats_long) != 5)
          .fail("Incorrect. Votre réponse doit avoir cinq colonnes.")
        
        if (!all(names(Q_croissance_stats_long) %in% names(.Q_croissance_stats_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : enfant, annee, tete, cou, hanche")
        
        if (isTRUE(all.equal(.Q_croissance_stats_long,
                             Q_croissance_stats_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_croissance_stats_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:7` pour sélectionner les colonnes à pivoter. 
  - Utilisez `names_to = c("year", ".value")` et `names_sep = "_"` pour formater les noms.
  ' -> out
  cat(out)
}

.SOLUTION_Q_croissance_stats_long <- function() {
  '
SOLUTION
  
  croissance_stats %>%
     pivot_longer(cols = 2:7,
                   names_to = c("annee", ".value"),
                   names_sep = "_")' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_enteropathogenes_zambie_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_enteropathogenes_zambie_large <- function() {
  
  .problem_number <<- 3
  
  .enteropathogenes_zambie_large <- suppressMessages(read_csv(here("data/fr_enteropathogenes_zambie_large.csv")))
  
  .Q_enteropathogenes_zambie_large <- 
    .enteropathogenes_zambie_large %>% 
    pivot_longer(!ID, 
                 names_to = c(".value", "numero_echantillon"), 
                 names_sep = "_")
  
  .autograder <<-
    function() {
      if (!exists("Q_enteropathogenes_zambie_large"))
        .na("Vous n'avez pas encore défini l'objet de réponse, `Q_enteropathogenes_zambie_large`.")
      
      if (!is.data.frame(Q_enteropathogenes_zambie_large))
        .na("Réponse invalide. Votre réponse doit être un dataframe.")
      
      if (ncol(Q_enteropathogenes_zambie_large) != 5)
        .fail("Incorrect. Votre réponse doit avoir cinq colonnes.")
      
      expected_cols <- c("ID", "numero_echantillon", "LPS", "LBP", "IFABP")
      if (!all(names(Q_enteropathogenes_zambie_large) %in% expected_cols))
        .fail(paste("Incorrect. Votre réponse doit avoir ces colonnes :", paste(expected_cols, collapse = ", ")))
      
      if (isTRUE(all.equal(.Q_enteropathogenes_zambie_large,
                           Q_enteropathogenes_zambie_large, ignore_col_order = TRUE, ignore_row_order = TRUE)))
        .pass("Correct !")
      else
        .fail("Incorrect. Veuillez réessayer.")
    }
  .run_autograder()
}

.HINT_Q_enteropathogenes_zambie_large <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse` pour réaliser la pivotisation.
  - Spécifiez les arguments `names_to = c(".value", "numero_echantillon")` et `names_sep = "_"`.
  ' -> out
  cat(out)
}

.SOLUTION_Q_enteropathogenes_zambie_large <- function() {
  '
SOLUTION
  
  enteropathogenes_zambie_large %>% 
    pivot_longer(!ID, 
                 names_to = c(".value", "numero_echantillon"), 
                 names_sep = "_")
  ' -> out
  cat(out)
}


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_adulte2_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_adulte2_long <-
  function() {
    
    .problem_number <<- 4
    
    .adulte_stats_point_sep <- 
      tibble::tribble(
        ~adulte,  ~`IMC.annee1`,  ~`IMC.annee2`,  ~`VIH.annee1`,  ~`VIH.annee2`,
        "A",            25,            30,    "Positive",   "Positive",
        "B",            34,            28,    "Negative",   "Positive",
        "C",            19,            17,    "Negative",   "Negative"
      )
    
    .Q_adulte2_long <- 
      .adulte_stats_point_sep %>%
      pivot_longer(cols = 2:5,
                   names_sep = "\\.",
                   names_to = c(".value", "annee"))
    
    .autograder <<-
      function() {
        if (!exists("Q_adulte2_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_adulte2_long`.")
        
        if (!is.data.frame(Q_adulte2_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_adulte2_long) != 4)
          .fail("Incorrect. Votre réponse doit avoir quatre colonnes.")
        
        if (!all(names(Q_adulte2_long) %in% names(.Q_adulte2_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : adulte, IMC, VIH, annee")
        
        if (isTRUE(all.equal(.Q_adulte2_long,
                             Q_adulte2_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_adulte2_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:5` pour sélectionner les colonnes à pivoter. 
  - N’oubliez pas d’échapper correctement le caractère point en utilisant `names_sep = "\\."` 
  et utilisez `names_to = c(".value", "year")` pour formater les noms.
  '  -> out
  cat(out)
}


.SOLUTION_Q_adulte2_long <- function() {
  '
SOLUTION
  
  adulte_stats_point_sep %>%
      pivot_longer(cols = 2:5,
                   names_sep = "\\.",
                   names_to = c(".value", "annee"))' -> out
  cat(out)
}



##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_diversite_alimentaire_vietnam_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_diversite_alimentaire_vietnam_large <-
  function() {
    
    .problem_number <<- 5
    
    .diversite_alimentaire_vietnam_large <- suppressMessages( read_csv(here("data/fr_diet_diversity_vietnam_wide.csv")))
    
    .Q_diversite_alimentaire_vietnam_large <- 
      .diversite_alimentaire_vietnam_large%>%
      rename(
        enerc_kcal_s__1 = enerc_kcal_s_1,
        enerc_kcal_s__2 = enerc_kcal_s_2,
        sec_s__1 = sec_s_1,
        sec_s__2 = sec_s_2,
        eau_s__1 = eau_s_1,
        eau_s__2 = eau_s_2,
        graisse_s__1 = graisse_s_1,
        graisse_s__2 = graisse_s_2
      ) %>%  
      pivot_longer(2:9, names_sep = "__", names_to = c(".value", "visite"))
    
    .autograder <<-
      function() {
        if (!exists("Q_diversite_alimentaire_vietnam_large"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_diversite_alimentaire_vietnam_large`.")
        
        if (!is.data.frame(Q_diversite_alimentaire_vietnam_large))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_diversite_alimentaire_vietnam_large) != 6)
          .fail("Incorrect. Votre réponse doit avoir six colonnes.")
        
        if (!all(names(Q_diversite_alimentaire_vietnam_large) %in% names(.Q_diversite_alimentaire_vietnam_large)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : menage_id, visite, enerc_kcal_s, sec_s, eau_s, graisse_s")
        
        if (isTRUE(all.equal(.Q_diversite_alimentaire_vietnam_large,
                             Q_diversite_alimentaire_vietnam_large, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_diversite_alimentaire_vietnam_large <- function() {
  '
INDICE.
  
  Commencez par renommer les colonnes en utilisant la fonction `rename` du package `tidyverse` afin qu’elles aient un séparateur double underscore. 
  - Ensuite, utilisez `pivot_longer` et spécifiez la plage de colonnes `2:9`.
  - Utilisez `names_sep = "__"` et `names_to = c(".value", "visit")` pour formater les noms.
  ' -> out
  cat(out)
}
.SOLUTION_Q_diversite_alimentaire_vietnam_large <- function() {
  '
SOLUTION
  
  diversite_alimentaire_vietnam_large%>%
      rename(
        enerc_kcal_s__1 = enerc_kcal_s_1,
        enerc_kcal_s__2 = enerc_kcal_s_2,
        sec_s__1 = sec_s_1,
        sec_s__2 = sec_s_2,
        eau_s__1 = eau_s_1,
        eau_s__2 = eau_s_2,
        graisse_s__1 = graisse_s_1,
        graisse_s__2 = graisse_s_2
      ) %>%  
      pivot_longer(2:9, names_sep = "__", names_to = c(".value", "visite"))
  ' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_tb_visites_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_tb_visites_large <-
  function() {
    
    .problem_number <<- 6
    
    .tb_visites_long <- 
      suppressMessages(read_csv(here("data/fr_india_tb_pathways_and_costs_data.csv"))) %>% 
      clean_names() %>% 
      select(id, premiere_visite_emplacement, premiere_visite_cout, 
             deuxieme_visite_emplacement, deuxieme_visite_cout, 
             troisieme_visite_emplacement, troisieme_visite_cout) %>% 
      rename(premiere__visite_emplacement = premiere_visite_emplacement, 
             premiere__visite_cout = premiere_visite_cout, 
             deuxieme__visite_emplacement = deuxieme_visite_emplacement, 
             deuxieme__visite_cout = deuxieme_visite_cout, 
             troisieme__visite_emplacement = troisieme_visite_emplacement, 
             troisieme__visite_cout = troisieme_visite_cout) %>% 
      pivot_longer(2:7, 
                   names_to = c("numero_visite", ".value"), 
                   names_sep = "__")
    
    
    .Q_tb_visites_large <- 
      .tb_visites_long %>%
      pivot_wider(names_from = numero_visite,
                  values_from = c(visite_emplacement, visite_cout)) %>%
      rename(
        c1 = 1,
        c2 = 2,
        c3 = 3,
        c4 = 4,
        c5 = 5,
        c6 = 6,
        c7 = 7
      )
    
    .autograder <<-
      function() {
        
        
        Q_tb_visites_large_renomme <- 
          Q_tb_visites_large %>% 
          rename(
            c1 = 1,
            c2 = 2,
            c3 = 3,
            c4 = 4,
            c5 = 5,
            c6 = 6,
            c7 = 7
          )
        
        
        if (!exists("Q_tb_visites_large"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_tb_visites_large`.")
        
        if (!is.data.frame(Q_tb_visites_large_renomme))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (!ncol(Q_tb_visites_large_renomme) == ncol(.Q_tb_visites_large))
          .fail(glue::glue("Incorrect. Votre réponse doit avoir {ncol(.Q_tb_visites_large)} colonnes."))
        
        if (! all(names(Q_tb_visites_large_renomme) %in% names(.Q_tb_visites_large)) )
          .fail(paste0("Incorrect. Votre réponse doit avoir ces colonnes:", 
                       paste0(names(.Q_tb_visites_large), collapse = ", ")
          ))
        
        if (isTRUE(suppressMessages(all.equal(Q_tb_visites_large_renomme,
                                              .Q_tb_visites_large, ignore_col_order = T, ignore_row_order = T))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_tb_visites_large <- function() {
  '
INDICE.
  
  Commencez par utiliser la fonction `pivot_wider` du package `tidyverse` sur le jeu de données `tb_visites_long`. 
  Vous voudrez spécifier quelles colonnes fourniront les nouveaux noms de colonnes (`names_from`) et de quelles colonnes obtenir les valeurs (`values_from`).
  Ensuite, utilisez la fonction `rename` pour changer les noms de colonnes comme requis.
  
  tb_visites_long %>%
    pivot_wider(_________)
  ' -> out
  cat(out)
}


.SOLUTION_Q_tb_visites_large <- function() {
  '
SOLUTION
  
  tb_visites_long %>%
      pivot_wider(names_from = numero_visite,
                  values_from = c(visite_emplacement, visite_cout))
      )' -> out
  cat(out)
}
if(!require('pacman')) install.packages('pacman')
pacman::p_load_gh('graph-courses/autograder')
pacman::p_load(here, 
               glue,
               praise,
               janitor,
               tidyverse)

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  INIT ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.scores <- rep(-1, times = 6)   # Put total number of questions as `times` argument

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_adulte_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.CHECK_Q_adulte_long <-
  function() {
    
    .problem_number <<- 1
    
    .adulte_stats <- 
      tibble::tribble(
        ~adulte,  ~annee1_IMC,  ~annee2_IMC,  ~annee1_VIH,  ~annee2_VIH,
        "A",          25,          30,  "Positive",  "Positive",
        "B",          34,          28,  "Negative",  "Positive",
        "C",          19,          17,  "Negative",  "Negative"
      )
    
    .Q_adulte_long <- 
      .adulte_stats %>%
      pivot_longer(cols = 2:5,
                   names_sep = "_",
                   names_to = c("annee", ".value"))
    
    .autograder <<-
      function() {
        if (!exists("Q_adulte_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_adulte_long`.")
        
        if (!is.data.frame(Q_adulte_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_adulte_long) != 4)
          .fail("Incorrect. Votre réponse doit avoir quatre colonnes.")
        
        if (!all(names(Q_adulte_long) %in% names(.Q_adulte_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : adulte, annee, IMC, VIH")
        
        if (isTRUE(all.equal(.Q_adulte_long,
                             Q_adulte_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_adulte_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:5` pour sélectionner les colonnes à pivoter. 
  - Utilisez `names_sep = "_"` et `names_to = c("year", ".value")` pour formater les noms.
  ' -> out
  cat(out)
}


.SOLUTION_Q_adulte_long <- function() {
  '
SOLUTION
  
  adulte_stats %>%
      pivot_longer(cols = 2:5,
                   names_sep = "_",
                   names_to = c("annee", ".value"))' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_croissance_stats_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_croissance_stats_long <-
  function() {
    
    .problem_number <<- 2
    
    .croissance_stats <- 
      tibble::tribble(
        ~enfant,~ann1_tete,~ann2_tete,~ann1_cou,~ann2_cou,~ann1_hanche,~ann2_hanche,
        "a",         45,        48,       23,       24,          51,          52,
        "b",         48,        50,       24,       26,          52,          52,
        "c",         50,        52,       24,       27,          53,          54
      )
    
    .Q_croissance_stats_long <- 
      .croissance_stats %>%
      pivot_longer(cols = 2:7,
                   names_to = c("annee", ".value"),
                   names_sep = "_")
    
    .autograder <<-
      function() {
        if (!exists("Q_croissance_stats_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_croissance_stats_long`.")
        
        if (!is.data.frame(Q_croissance_stats_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_croissance_stats_long) != 5)
          .fail("Incorrect. Votre réponse doit avoir cinq colonnes.")
        
        if (!all(names(Q_croissance_stats_long) %in% names(.Q_croissance_stats_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : enfant, annee, tete, cou, hanche")
        
        if (isTRUE(all.equal(.Q_croissance_stats_long,
                             Q_croissance_stats_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_croissance_stats_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:7` pour sélectionner les colonnes à pivoter. 
  - Utilisez `names_to = c("year", ".value")` et `names_sep = "_"` pour formater les noms.
  ' -> out
  cat(out)
}

.SOLUTION_Q_croissance_stats_long <- function() {
  '
SOLUTION
  
  croissance_stats %>%
     pivot_longer(cols = 2:7,
                   names_to = c("annee", ".value"),
                   names_sep = "_")' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_enteropathogenes_zambie_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_enteropathogenes_zambie_large <- function() {
  
  .problem_number <<- 3
  
  .enteropathogenes_zambie_large <- suppressMessages(read_csv(here("data/fr_enteropathogenes_zambie_large.csv")))
  
  .Q_enteropathogenes_zambie_large <- 
    .enteropathogenes_zambie_large %>% 
    pivot_longer(!ID, 
                 names_to = c(".value", "numero_echantillon"), 
                 names_sep = "_")
  
  .autograder <<-
    function() {
      if (!exists("Q_enteropathogenes_zambie_large"))
        .na("Vous n'avez pas encore défini l'objet de réponse, `Q_enteropathogenes_zambie_large`.")
      
      if (!is.data.frame(Q_enteropathogenes_zambie_large))
        .na("Réponse invalide. Votre réponse doit être un dataframe.")
      
      if (ncol(Q_enteropathogenes_zambie_large) != 5)
        .fail("Incorrect. Votre réponse doit avoir cinq colonnes.")
      
      expected_cols <- c("ID", "numero_echantillon", "LPS", "LBP", "IFABP")
      if (!all(names(Q_enteropathogenes_zambie_large) %in% expected_cols))
        .fail(paste("Incorrect. Votre réponse doit avoir ces colonnes :", paste(expected_cols, collapse = ", ")))
      
      if (isTRUE(all.equal(.Q_enteropathogenes_zambie_large,
                           Q_enteropathogenes_zambie_large, ignore_col_order = TRUE, ignore_row_order = TRUE)))
        .pass("Correct !")
      else
        .fail("Incorrect. Veuillez réessayer.")
    }
  .run_autograder()
}

.HINT_Q_enteropathogenes_zambie_large <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse` pour réaliser la pivotisation.
  - Spécifiez les arguments `names_to = c(".value", "numero_echantillon")` et `names_sep = "_"`.
  ' -> out
  cat(out)
}

.SOLUTION_Q_enteropathogenes_zambie_large <- function() {
  '
SOLUTION
  
  enteropathogenes_zambie_large %>% 
    pivot_longer(!ID, 
                 names_to = c(".value", "numero_echantillon"), 
                 names_sep = "_")
  ' -> out
  cat(out)
}


##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_adulte2_long ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_adulte2_long <-
  function() {
    
    .problem_number <<- 4
    
    .adulte_stats_point_sep <- 
      tibble::tribble(
        ~adulte,  ~`IMC.annee1`,  ~`IMC.annee2`,  ~`VIH.annee1`,  ~`VIH.annee2`,
        "A",            25,            30,    "Positive",   "Positive",
        "B",            34,            28,    "Negative",   "Positive",
        "C",            19,            17,    "Negative",   "Negative"
      )
    
    .Q_adulte2_long <- 
      .adulte_stats_point_sep %>%
      pivot_longer(cols = 2:5,
                   names_sep = "\\.",
                   names_to = c(".value", "annee"))
    
    .autograder <<-
      function() {
        if (!exists("Q_adulte2_long"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_adulte2_long`.")
        
        if (!is.data.frame(Q_adulte2_long))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_adulte2_long) != 4)
          .fail("Incorrect. Votre réponse doit avoir quatre colonnes.")
        
        if (!all(names(Q_adulte2_long) %in% names(.Q_adulte2_long)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : adulte, IMC, VIH, annee")
        
        if (isTRUE(all.equal(.Q_adulte2_long,
                             Q_adulte2_long, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_adulte2_long <- function() {
  '
INDICE.
  
  Utilisez la fonction `pivot_longer` du package `tidyverse`. 
  - Spécifiez `cols = 2:5` pour sélectionner les colonnes à pivoter. 
  - N’oubliez pas d’échapper correctement le caractère point en utilisant `names_sep = "\\."` 
  et utilisez `names_to = c(".value", "year")` pour formater les noms.
  '  -> out
  cat(out)
}


.SOLUTION_Q_adulte2_long <- function() {
  '
SOLUTION
  
  adulte_stats_point_sep %>%
      pivot_longer(cols = 2:5,
                   names_sep = "\\.",
                   names_to = c(".value", "annee"))' -> out
  cat(out)
}



##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_diversite_alimentaire_vietnam_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_diversite_alimentaire_vietnam_large <-
  function() {
    
    .problem_number <<- 5
    
    .diversite_alimentaire_vietnam_large <- suppressMessages( read_csv(here("data/fr_diet_diversity_vietnam_wide.csv")))
    
    .Q_diversite_alimentaire_vietnam_large <- 
      .diversite_alimentaire_vietnam_large%>%
      rename(
        enerc_kcal_s__1 = enerc_kcal_s_1,
        enerc_kcal_s__2 = enerc_kcal_s_2,
        sec_s__1 = sec_s_1,
        sec_s__2 = sec_s_2,
        eau_s__1 = eau_s_1,
        eau_s__2 = eau_s_2,
        graisse_s__1 = graisse_s_1,
        graisse_s__2 = graisse_s_2
      ) %>%  
      pivot_longer(2:9, names_sep = "__", names_to = c(".value", "visite"))
    
    .autograder <<-
      function() {
        if (!exists("Q_diversite_alimentaire_vietnam_large"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_diversite_alimentaire_vietnam_large`.")
        
        if (!is.data.frame(Q_diversite_alimentaire_vietnam_large))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (ncol(Q_diversite_alimentaire_vietnam_large) != 6)
          .fail("Incorrect. Votre réponse doit avoir six colonnes.")
        
        if (!all(names(Q_diversite_alimentaire_vietnam_large) %in% names(.Q_diversite_alimentaire_vietnam_large)) )
          .fail("Incorrect. Votre réponse doit avoir ces colonnes : menage_id, visite, enerc_kcal_s, sec_s, eau_s, graisse_s")
        
        if (isTRUE(all.equal(.Q_diversite_alimentaire_vietnam_large,
                             Q_diversite_alimentaire_vietnam_large, ignore_col_order = T, ignore_row_order = T)))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_diversite_alimentaire_vietnam_large <- function() {
  '
INDICE.
  
  Commencez par renommer les colonnes en utilisant la fonction `rename` du package `tidyverse` afin qu’elles aient un séparateur double underscore. 
  - Ensuite, utilisez `pivot_longer` et spécifiez la plage de colonnes `2:9`.
  - Utilisez `names_sep = "__"` et `names_to = c(".value", "visit")` pour formater les noms.
  ' -> out
  cat(out)
}
.SOLUTION_Q_diversite_alimentaire_vietnam_large <- function() {
  '
SOLUTION
  
  diversite_alimentaire_vietnam_large%>%
      rename(
        enerc_kcal_s__1 = enerc_kcal_s_1,
        enerc_kcal_s__2 = enerc_kcal_s_2,
        sec_s__1 = sec_s_1,
        sec_s__2 = sec_s_2,
        eau_s__1 = eau_s_1,
        eau_s__2 = eau_s_2,
        graisse_s__1 = graisse_s_1,
        graisse_s__2 = graisse_s_2
      ) %>%  
      pivot_longer(2:9, names_sep = "__", names_to = c(".value", "visite"))
  ' -> out
  cat(out)
}

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## ~  Q_tb_visites_large ----
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.CHECK_Q_tb_visites_large <-
  function() {
    
    .problem_number <<- 6
    
    .tb_visites_long <- 
      suppressMessages(read_csv(here("data/fr_india_tb_pathways_and_costs_data.csv"))) %>% 
      clean_names() %>% 
      select(id, premiere_visite_emplacement, premiere_visite_cout, 
             deuxieme_visite_emplacement, deuxieme_visite_cout, 
             troisieme_visite_emplacement, troisieme_visite_cout) %>% 
      rename(premiere__visite_emplacement = premiere_visite_emplacement, 
             premiere__visite_cout = premiere_visite_cout, 
             deuxieme__visite_emplacement = deuxieme_visite_emplacement, 
             deuxieme__visite_cout = deuxieme_visite_cout, 
             troisieme__visite_emplacement = troisieme_visite_emplacement, 
             troisieme__visite_cout = troisieme_visite_cout) %>% 
      pivot_longer(2:7, 
                   names_to = c("numero_visite", ".value"), 
                   names_sep = "__")
    
    
    .Q_tb_visites_large <- 
      .tb_visites_long %>%
      pivot_wider(names_from = numero_visite,
                  values_from = c(visite_emplacement, visite_cout)) %>%
      rename(
        c1 = 1,
        c2 = 2,
        c3 = 3,
        c4 = 4,
        c5 = 5,
        c6 = 6,
        c7 = 7
      )
    
    .autograder <<-
      function() {
        
        
        Q_tb_visites_large_renomme <- 
          Q_tb_visites_large %>% 
          rename(
            c1 = 1,
            c2 = 2,
            c3 = 3,
            c4 = 4,
            c5 = 5,
            c6 = 6,
            c7 = 7
          )
        
        
        if (!exists("Q_tb_visites_large"))
          .na("Vous n'avez pas encore défini l'objet de réponse, `Q_tb_visites_large`.")
        
        if (!is.data.frame(Q_tb_visites_large_renomme))
          .na("Réponse invalide. Votre réponse doit être un dataframe.")
        
        if (!ncol(Q_tb_visites_large_renomme) == ncol(.Q_tb_visites_large))
          .fail(glue::glue("Incorrect. Votre réponse doit avoir {ncol(.Q_tb_visites_large)} colonnes."))
        
        if (! all(names(Q_tb_visites_large_renomme) %in% names(.Q_tb_visites_large)) )
          .fail(paste0("Incorrect. Votre réponse doit avoir ces colonnes:", 
                       paste0(names(.Q_tb_visites_large), collapse = ", ")
          ))
        
        if (isTRUE(suppressMessages(all.equal(Q_tb_visites_large_renomme,
                                              .Q_tb_visites_large, ignore_col_order = T, ignore_row_order = T))))
          .pass("Correct !")
        
        else
          .fail("Incorrect. Veuillez réessayer.")
      }
    .run_autograder()
  }

.HINT_Q_tb_visites_large <- function() {
  '
INDICE.
  
  Commencez par utiliser la fonction `pivot_wider` du package `tidyverse` sur le jeu de données `tb_visites_long`. 
  Vous voudrez spécifier quelles colonnes fourniront les nouveaux noms de colonnes (`names_from`) et de quelles colonnes obtenir les valeurs (`values_from`).
  Ensuite, utilisez la fonction `rename` pour changer les noms de colonnes comme requis.
  
  tb_visites_long %>%
    pivot_wider(_________)
  ' -> out
  cat(out)
}


.SOLUTION_Q_tb_visites_large <- function() {
  '
SOLUTION
  
  tb_visites_long %>%
      pivot_wider(names_from = numero_visite,
                  values_from = c(visite_emplacement, visite_cout))
      )' -> out
  cat(out)
}
